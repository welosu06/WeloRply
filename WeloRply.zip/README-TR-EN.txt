WELO RPLY — v0.12.4 beta

TÜRKÇE: Adım adım kurulum için docs/KURULUM-TR.md dosyasını aç.
GitHub'dan okumak için: https://github.com/welosu06/WeloRply/blob/main/docs/KURULUM-TR.md

ENGLISH: Open docs/SETUP-EN.md for step-by-step instructions.
Read online: https://github.com/welosu06/WeloRply/blob/main/docs/SETUP-EN.md

Eklenti Chrome'da Welo Reply adıyla görünür. ZIP'i çıkar, chrome://extensions üzerinden manifest.json içeren klasörü yükle. Kurulum düğmesi yan panelin içindedir. GitHub kurulumu otomatik güncellenmez.
The extension appears as Welo Reply in Chrome. Extract the ZIP and load the folder containing manifest.json via chrome://extensions. Setup is inside the side panel. GitHub installations do not update automatically.

Kuyruk sırasında paneli açık tut. Sonucu belirsiz gönderimi tekrar denemeden önce X'te kontrol et.
Keep the side panel open during queue processing. Check uncertain sends on X before retrying.
