WELO REPLY — 0.12.11 beta

TÜRKÇE: Önce KURULUM.txt, sonra docs/KURULUM-TR.md dosyasını aç.
ENGLISH: Open docs/SETUP-EN.md for numbered installation instructions.

Download / İndir: https://github.com/welosu06/WeloRply/raw/refs/heads/main/WeloRply.zip
Türkçe: https://github.com/welosu06/WeloRply/blob/main/docs/KURULUM-TR.md
English: https://github.com/welosu06/WeloRply/blob/main/docs/SETUP-EN.md

Chrome: Welo Reply. Extract the ZIP and load the folder containing manifest.json.
Mac: Extract setup/welo-mac.zip and double-click Kur.command. If prompted,
quit Ollama from its menu bar icon, then press Enter in the installer.
Windows: Extract setup/welo-win.zip and run Setup.ps1 with PowerShell.

Keep the extension folder. Updates from GitHub are manual.
Kuyruk sırasında paneli açık tut. Keep the side panel open while the queue runs.
