v0.12.1: İlk kurulum artık yan panelin içindedir. Panel açılırken kurulum sekmesi açılmaz. Kurulum düğmesine bas; Geri ile ana ekrana dön.
First-time setup now opens inside the side panel only when you click Setup. Opening the panel no longer opens a setup tab. Use Back to return.

WELO REPLY v0.12.1 — TR / EN

TÜRKÇE
1. ZIP dosyasını kalıcı bir klasöre çıkar.
2. Chrome adres çubuğuna chrome://extensions yaz.
3. Geliştirici modunu aç. Paketlenmemiş öğe yükle düğmesine bas.
4. manifest.json dosyasının bulunduğu klasörü seç.
5. Eski eklentiyi güncelliyorsan aynı klasörde dosyaları değiştir ve eklenti kartındaki Yenile düğmesine bas. Açık X sayfalarını da yenile.
6. Welo panelinin üstündeki Arayüz dili alanından TR · Türkçe veya EN · English seç.

Dil seçimin kaydedilir; açık Welo panelleri birlikte güncellenir. Yorum dili gönderiye göre belirlenmeye devam eder. Özel talimatların, test metnin ve üretilen yorumların çevrilmez.
Bu sürüm eklentinin yan panelini, küçük ayar panelini, kurulum/model indirme sayfalarını, kısayollarını ve uygulama mesajlarını iki dilli yapar. Ayrı Windows/Mac yardımcı paketlerinin kendi kurulum arayüzü bu güncellemede değişmedi.

ENGLISH
1. Extract this ZIP to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Enable Developer mode and select Load unpacked.
4. Select the folder containing manifest.json.
5. To update an existing installation, replace its files in the same folder, click Reload on its extension card, then refresh your open X tabs.
6. Select TR · Türkçe or EN · English using Interface language at the top of the Welo panel.

Your selection is saved and synchronized across open Welo panels. Replies continue to follow the post's language. Custom instructions, test input and generated replies are not translated.
The extension UI is bilingual. The separate Windows/Mac helper installers are unchanged in this release.

