(()=>{
 const button=document.getElementById('hardRefresh'),status=document.getElementById('refreshStatus');
 button.addEventListener('click',async()=>{
  button.disabled=true;status.textContent='';
  try{
   const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
   if(!Number.isInteger(tab?.id))throw Error('Yenilenecek açık sekme bulunamadı.');
   await chrome.tabs.reload(tab.id,{bypassCache:true});
   status.textContent='Yenileme başlatıldı.';
  }catch(e){status.textContent=e.message;}
  finally{button.disabled=false;}
 });
})();
