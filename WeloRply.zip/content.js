(()=>{
 if(window.__yerelXVersion==='0.12.7')return;window.__yerelXVersion='0.12.7';
 const sleep=async ms=>{if(document.hidden){try{const r=await chrome.runtime.sendMessage({type:'typingDelay',ms});if(r?.ok)return;}catch{}}return new Promise(r=>setTimeout(r,ms));};let busy=false,cancel=false,queueStage='Gönderi metni bekleniyor…';
 const id=u=>String(u).match(/\/status\/(\d+)/)?.[1];
 const own=a=>id([...a.querySelectorAll('a[href*="/status/"]')].find(l=>l.querySelector('time'))?.href);
 const visible=e=>e&&e.getClientRects().length;
 async function wait(fn,ms=20000){const end=Date.now()+ms;while(Date.now()<end){if(cancel)throw Error('Durduruldu.');const v=fn();if(v)return v;await sleep(200);}throw Error('X arayüzü beklenen alanı göstermedi. Açık sekmeyi kontrol et.');}
 function toast(text,error=false){
  queueStage=text;
  globalThis.WeloFloat?.status(text,error);
  let t=document.getElementById('yerel-x-toast');if(!t){t=document.createElement('div');t.id='yerel-x-toast';t.setAttribute('role','status');document.body.append(t);}
  t.style.cssText='position:fixed!important;bottom:24px!important;right:24px!important;z-index:2147483647!important;max-width:min(360px,85vw)!important;padding:14px 18px!important;border-radius:12px!important;box-shadow:0 6px 28px #0003!important;font:14px/1.5 system-ui!important;white-space:normal!important;background:'+(error?'#fff1f2':'#eff6ff')+'!important;color:'+(error?'#991b1b':'#163a65')+'!important;border:1px solid '+(error?'#fecaca':'#bfdbfe')+'!important;';
  WeloI18n.observe(t);t.textContent=text;clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.remove(),error?18000:9000);
 }

 // X can wrap or replace its editable node while React processes input.
 const normalText=value=>String(value||'').normalize('NFC').replace(/[\u200B\uFEFF]/g,'').replace(/\s+/gu,' ').trim();
 function editorIn(dialog){
  const candidates=[...dialog.querySelectorAll('[data-testid^="tweetTextarea_"]')];
  for(const container of candidates){
   const editor=container.matches('[contenteditable="true"]')?container:container.querySelector('[contenteditable="true"]');
   if(visible(editor)&&editor.getAttribute('aria-disabled')!=='true')return editor;
  }
  return null;
 }

 // During typing, trailing spaces are meaningful: do not treat a pending space as already inserted.
 const typingText=value=>String(value||'').normalize('NFC').replace(/[\u200B\uFEFF]/g,'').replace(/\r\n?/g,'\n').replace(/\n+$/g,'').replace(/\s+/gu,' ');
 function editorText(editor){return editor.innerText;}
 // Managed editors must receive state-aware input, not simultaneous native DOM insertion.
 function managedEditor(editor){return !!editor.querySelector('[data-contents="true"], [data-block="true"]');}
 function insertIntoEditor(editor,text){
  if(!managedEditor(editor))return document.execCommand('insertText',false,text);
  const transfer=new DataTransfer();transfer.setData('text/plain',text);
  editor.dispatchEvent(new ClipboardEvent('paste',{clipboardData:transfer,bubbles:true,cancelable:true}));
  // Never retry a managed paste with a second insertion while rendering is pending.
  return true;
 }
 function deleteFromEditor(editor){
  if(managedEditor(editor)){
   const event=new KeyboardEvent('keydown',{key:'Backspace',code:'Backspace',keyCode:8,which:8,bubbles:true,cancelable:true});
   const before=editorText(editor);
   editor.dispatchEvent(event);
   // Synthetic keydown has no browser default action. If the editor handled it,
   // never delete twice; otherwise perform the native editing command ourselves.
   if(event.defaultPrevented||editorText(editor)!==before)return true;
   return document.execCommand('delete',false);
  }
  return document.execCommand('delete',false);
 }

 function placeCaret(editor){
  editor.focus({preventScroll:true});
  const blocks=editor.querySelectorAll('[data-block="true"]');
  const root=blocks.length?blocks[blocks.length-1]:(editor.querySelector('[data-contents="true"]')||editor);
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:node=>node.parentElement?.closest('[contenteditable="false"]')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});
  let node,last;while(node=walker.nextNode())if(node.length)last=node;
  const range=document.createRange();
  if(last)range.setStart(last,last.length);
  else {const leaves=root.querySelectorAll('[data-text="true"], [data-offset-key]');const leaf=leaves.length?leaves[leaves.length-1]:root;if(leaf.tagName==='BR')range.setStartBefore(leaf);else range.selectNodeContents(leaf);}
  range.collapse(false);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);
 }
 async function waitForTyped(dialog,text,isInterrupted,timeout=30000){
  const deadline=Date.now()+timeout;let since=0,last=null;
  while(Date.now()<deadline){
   if(cancel)throw Error('İşlem durduruldu. Taslak gönderilmedi.');
   if(isInterrupted())throw Error('Yanıt alanında tıklama veya klavye kullanımı algılandı. Yazım durduruldu; taslak korunuyor.');
   const editor=editorIn(dialog);
   if(editor&&typingText(editorText(editor))===typingText(text)){
    if(last!==editor){last=editor;since=Date.now();}
    if(Date.now()-since>=120)return true;
   }else{last=null;since=0;}
   await sleep(30);
  }
  return false;
 }

 function matchesReply(dialog,text){const editor=editorIn(dialog);return !!editor&&normalText(editorText(editor))===normalText(text);}
 async function settleReply(dialog,text,timeout=30000){
  const deadline=Date.now()+timeout;let stableSince=0,lastEditor=null;
  while(Date.now()<deadline){
   if(cancel)throw Error('Durduruldu.');
   const editor=editorIn(dialog);
   if(editor&&normalText(editorText(editor))===normalText(text)){
    if(editor!==lastEditor){lastEditor=editor;stableSince=Date.now();}
    if(Date.now()-stableSince>=400)return editor;
   }else{lastEditor=null;stableSince=0;}
   await sleep(100);
  }
  return null;
 }

 async function typeReply(dialog,text,corrections){
  if(!globalThis.WeloTyping)throw Error('Yazım bileşeni yüklenmedi. X sayfasını yenile.');
  let expected='',applying=false,interrupted=false;
  // beforeinput may be emitted later by X for our own insertion. It is not proof of a user's action.
  const userSignals=['keydown','pointerdown','paste','compositionstart'];
  const userEdit=event=>{if(userSignals.includes(event.type)&&event.isTrusted&&!applying)interrupted=true;};
  for(const name of userSignals)dialog.addEventListener(name,userEdit,true);
  try{
   const {actions}=WeloTyping.plan(text,{corrections});
   toast('Yorum harf harf yazılıyor… Yazmayı durdurmak için yanıt alanına tıklayabilirsin.');
   for(const action of actions){
    if(cancel)throw Error('İşlem durduruldu. Taslak gönderilmedi.');
    if(interrupted)throw Error('Yanıt alanında tıklama veya klavye kullanımı algılandı. Yazım durduruldu; taslak korunuyor.');
    if(action.kind==='pause'){await sleep(550+Math.random()*250);continue;}
    const editor=editorIn(dialog);
    if(!editor||typingText(editorText(editor))!==typingText(expected))throw Error('Yanıt alanı değişti. Yazım durduruldu; taslak gönderilmedi.');
    placeCaret(editor);
    applying=true;
    try{
     const ok=action.kind==='delete'?deleteFromEditor(editor):insertIntoEditor(editor,action.text);
     if(!ok)throw Error('X harf harf yazmayı kabul etmedi. Taslak gönderilmedi.');
    }finally{applying=false;}
    expected=action.kind==='delete'?WeloTyping.split(expected).slice(0,-1).join(''):expected+action.text;
    await sleep(45+Math.random()*65);
    if(!await waitForTyped(dialog,expected,()=>interrupted))throw Error(action.kind==='delete'?'X yanlış harfi silmedi. Taslak gönderilmedi; sayfayı yenileyip tekrar dene.':'X son yazılan harfi kaydetmedi. Taslak gönderilmedi; açık yanıt penceresini kapatıp tekrar dene.');
   }
   if(cancel)throw Error('İşlem durduruldu. Taslak gönderilmedi.');
   if(interrupted)throw Error('Yanıt alanında tıklama veya klavye kullanımı algılandı. Yazım durduruldu; taslak korunuyor.');
   if(!await settleReply(dialog,text))throw Error('Son yorum doğrulanamadı. Taslak gönderilmedi.');
  }finally{for(const name of userSignals)dialog.removeEventListener(name,userEdit,true);}
 }

 async function fillReply(dialog,text){
  let editor=await wait(()=>editorIn(dialog));
  if(normalText(editorText(editor)))throw Error('Yanıt alanında mevcut taslak var; üzerine yazılmadı.');
  editor.focus({preventScroll:true});
  const {slowTyping=false,typingCorrections=true}=await chrome.storage.local.get(['slowTyping','typingCorrections']);
  if(slowTyping){await typeReply(dialog,text,typingCorrections);return;}
  placeCaret(editor);
  let inserted=false;try{inserted=insertIntoEditor(editor,text);}catch{}
  if(await settleReply(dialog,text))return;
  // Never append to or replace unexpected text: it may be the user's own draft.
  editor=editorIn(dialog);
  if(!editor)throw Error('X yanıt kutusunu yeniden oluşturdu. Pencereyi kapatıp tekrar dene.');
  if(!normalText(editorText(editor))&&!inserted){
   editor.focus({preventScroll:true});
   const transfer=new DataTransfer();transfer.setData('text/plain',text);
   editor.dispatchEvent(new ClipboardEvent('paste',{clipboardData:transfer,bubbles:true,cancelable:true}));
   if(await settleReply(dialog,text))return;
  }
  throw Error(normalText(editorText(editor))?'X yanıt kutusundaki yazı üretilen yorumla eşleşmedi. Gönderilmedi; taslağı kontrol et.':'X yanıt kutusu yazıyı kabul etmedi. Pencereyi kapatıp sayfayı yenile ve tekrar dene.');
 }

 async function like(a){
  if(a.querySelector('[data-testid="unlike"]'))return 'Zaten beğenilmiş.';
  const target=own(a);const button=a.querySelector('[data-testid="like"]');
  if(!target||!button)throw Error('Beğeni düğmesi bulunamadı.');
  button.click();
  await wait(()=>{const current=a.isConnected&&own(a)===target?a:[...document.querySelectorAll('article[data-testid="tweet"]')].find(x=>own(x)===target);return current?.querySelector('[data-testid="unlike"]');},8000);
  return 'Gönderi beğenildi.';
 }
 async function run(a,mode='send'){
  if(busy)throw Error('Bu sekmede başka bir yorum işlemi var.');busy=true;cancel=false;let clicked=false,retrySafe=false;
  try{
   const target=own(a);if(!target)throw Error('Gönderi kimliği okunamadı.');
   const key='sent_'+target;const history=await chrome.storage.local.get([key,'allowRepeatReplies']);const previousRecord=history[key];
   const restoreRecord=()=>previousRecord?chrome.storage.local.set({[key]:previousRecord}):chrome.storage.local.remove(key);
   if(mode==='send'&&previousRecord&&history.allowRepeatReplies!==true)throw Error('Bu gönderi için önceki gönderim kaydı var. Tekrar gönderilmedi.');
   const text=WeloPostText.read(a);if(!text)throw Error('Gönderide okunabilir metin yok.');
   toast('Ollama yorum üretiyor… İlk model yüklemesi biraz sürebilir.');
   retrySafe=true;const r=await chrome.runtime.sendMessage({type:'generate',text});if(!r?.ok)throw Error(r?.error||'Yerel model yanıt vermedi.');retrySafe=false;
   if(cancel)throw Error('Durduruldu.');
   if(!a.isConnected||own(a)!==target)throw Error('Gönderi sayfadan ayrıldı. Gönderiye dönüp yeniden dene.');
   if(document.querySelector('[role="dialog"]'))throw Error('Açık pencereyi kapatıp yeniden dene.');
   const b=a.querySelector('[data-testid="reply"]');if(!b)throw Error('Yanıt düğmesi bulunamadı.');b.click();
   const d=await wait(()=>[...document.querySelectorAll('[role="dialog"]')].find(x=>editorIn(x)));
   await fillReply(d,r.text);
   if(mode==='draft')return {text:r.text,draft:true};
   const pacing=await chrome.storage.local.get('pacingEnabled');
   if(pacing.pacingEnabled===true){const slot=await chrome.runtime.sendMessage({type:'sendSlot'});if(!slot?.ok)throw Error(slot?.error||'Bekleme süresi alınamadı.');const end=Date.now()+Math.max(0,Number(slot.waitMs)||0);while(Date.now()<end){if(cancel)throw Error('İşlem durduruldu. Taslak gönderilmedi.');const current=await chrome.storage.local.get('pacingEnabled');if(current.pacingEnabled!==true)break;toast('Yorum hazır · gönderime '+Math.ceil((end-Date.now())/1000)+' sn.');await sleep(Math.min(250,end-Date.now()));}}

   const send=await wait(()=>{const x=d.querySelector('[data-testid="tweetButton"], [data-testid="tweetButtonInline"]');return visible(x)&&!x.disabled&&x.getAttribute('aria-disabled')!=='true'?x:null;});
   if(!matchesReply(d,r.text))throw Error('Yanıt metni değişti. Gönderilmedi; taslağı kontrol et.');
   await chrome.storage.local.set({[key]:{status:'pending',text:r.text,time:Date.now()}});
   if(cancel){await restoreRecord();throw Error('Durduruldu.');}
   if(!matchesReply(d,r.text)||!send.isConnected||send.disabled||send.getAttribute('aria-disabled')==='true'){await restoreRecord();throw Error('Yanıt alanı değişti. Gönderilmedi; taslağı kontrol et.');}
   send.click();clicked=true;
   await wait(()=>!d.isConnected||!visible(d));
   await chrome.storage.local.set({[key]:{status:'submitted',text:r.text,time:Date.now()}});
   let likeStatus='';const {autoLike=false}=await chrome.storage.local.get('autoLike');
   if(autoLike&&!cancel){try{const current=a.isConnected&&own(a)===target?a:[...document.querySelectorAll('article[data-testid="tweet"]')].find(x=>own(x)===target);if(!current)throw Error('Gönderi görünmüyor.');likeStatus=await like(current);}catch(e){likeStatus='Yorum gönderildi, beğeni tamamlanamadı: '+e.message;}}
   return {text:r.text,draft:false,likeStatus};
  }catch(e){const failure=Error(e.message+(clicked?' Gönderim sonucu belirsiz; tekrar denemeden önce X üzerinde kontrol et.':''));failure.retrySafe=retrySafe&&!clicked&&!cancel;throw failure;}finally{busy=false;}
 }
 chrome.runtime.onMessage.addListener((m,s,reply)=>{
  if(s.id!==chrome.runtime.id)return;
  if(m.type==='taskNotice'){toast(m.text,!!m.error);reply({ok:true});return;}
  if(m.type==='ping'){reply({ok:true,version:'0.12.7',stage:queueStage,busy});return;}
  if(m.type==='cancel'){cancel=true;reply({ok:true});return;}
  if(m.type!=='replyTo')return;
  (async()=>{cancel=false;const target=id(m.url);if(!target||id(location.href)!==target)throw Error('Hedef gönderi açık değil.');return run(await wait(()=>[...document.querySelectorAll('article[data-testid="tweet"]')].find(a=>own(a)===target)));})().then(v=>reply({ok:true,...v})).catch(e=>reply({ok:false,error:e.message,retrySafe:e.retrySafe===true}));return true;
 });
 async function saveLink(a){
  const target=own(a);if(!target)throw Error('Gönderi linki okunamadı.');
  const {savedLinks=[]}=await chrome.storage.local.get('savedLinks');
  const url='https://x.com/i/web/status/'+target;
  if(!savedLinks.some(u=>id(u)===target))await chrome.storage.local.set({savedLinks:[...savedLinks,url]});
  toast('Link yan paneldeki listeye eklendi.');
 }
 function scan(){for(const a of document.querySelectorAll('article[data-testid="tweet"]')){
  const target=own(a);const reply=a.querySelector('[data-testid="reply"]');const row=reply?.closest('[role="group"]');
  if(!target||!row)continue;
  const old=a.querySelector('[data-local-x-toolbar]');if(old?.dataset.target===target&&old.dataset.weloVersion==='0.12.7')continue;if(old)old.remove();
  const host=document.createElement('span');host.dataset.localXToolbar='';host.dataset.target=target;host.dataset.weloVersion='0.12.7';
  host.style.cssText='display:inline-flex!important;flex:0 0 auto!important;width:auto!important;height:32px!important;align-self:center!important;margin-left:5px!important;vertical-align:middle!important;';
  const shadow=host.attachShadow({mode:'open'});const style=document.createElement('style');
  style.textContent=':host{line-height:1} .bar{display:flex;gap:4px;height:32px;align-items:center}button{appearance:none;box-sizing:border-box;display:grid;place-items:center;flex:none;width:25px;height:32px;padding:0;border:0;border-radius:5px;font:16px system-ui;cursor:pointer;color:white;box-shadow:0 1px 2px #0001}button:hover{filter:brightness(.92)}button:focus-visible{outline:2px solid #1d4ed8;outline-offset:2px}button:disabled{opacity:.45;cursor:wait}.draft{background:#f4b400}.send{background:#ef4444}.save{background:#8b5cf6}.panel{background:#10b981}';
  const bar=document.createElement('span');bar.className='bar';shadow.append(style,bar);
  for(const [mode,icon,title] of [['draft','✍','Yorum üret ve taslak olarak aç'],['send','ϟ','Yorum üret ve hemen gönder'],['save','▣','Linki yan paneldeki listeye ekle'],['panel','+','Yerel X yan panelini aç']]){
   WeloI18n.observe(shadow);const b=document.createElement('button');b.className=mode;b.type='button';b.textContent=icon;b.title=title;b.setAttribute('aria-label',title);
   b.onclick=async e=>{
    e.preventDefault();e.stopPropagation();
    if(mode==='panel'){chrome.runtime.sendMessage({type:'openPanel'}).then(r=>{if(!r?.ok)toast(r?.error||'Üstteki eklenti simgesinden paneli aç.',true);}).catch(e=>toast(e.message,true));return;}
    b.disabled=true;
    try{if(mode==='save')await saveLink(a);else if(mode==='send'){const target=own(a);if(!target)throw Error('Gönderi kimliği okunamadı.');const result=await chrome.runtime.sendMessage({type:'startReplyTask',postId:target});if(!result?.ok)throw Error(result?.error||'Görev başlatılamadı.');toast('Yorum ayrı görev sekmesinde hazırlanıyor. Başka sekmeye geçebilirsin.');}else{const r=await run(a,mode);toast(r.draft?'Yorum taslağı hazır. İnceleyip X’ten gönderebilirsin.':'Gönderim yapıldı: '+r.text+(r.likeStatus?' '+r.likeStatus:''));}}
    catch(e){toast(e.message,true);}finally{b.disabled=false;}
   };bar.append(b);
  }
  row.append(host);
 }}
 async function startAssignedTask(){
  const response=await chrome.runtime.sendMessage({type:'claimReplyTask'});
  if(!response?.job){if(response?.error)toast(response.error,true);return;}
  const job=response.job;
  try{const target=id(job.url);if(id(location.href)!==target)throw Error('Görev sayfası hedef gönderiyle eşleşmiyor.');const article=await wait(()=>[...document.querySelectorAll('article[data-testid="tweet"]')].find(a=>own(a)===target),60000);const result=await run(article,'send');await chrome.runtime.sendMessage({type:'finishReplyTask',jobId:job.id,ok:true,text:result.text});toast('Görev tamamlandı: yorum gönderildi.');}
  catch(e){await chrome.runtime.sendMessage({type:'finishReplyTask',jobId:job.id,ok:false,error:e.message}).catch(()=>{});toast(e.message,true);}
 }
 startAssignedTask().catch(()=>{});
 let timer;new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(scan,200);}).observe(document.body,{childList:true,subtree:true});scan();
})();


