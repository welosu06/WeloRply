const WeloPlatform={
 async get(){try{return await chrome.runtime.getPlatformInfo();}catch{return {os:'unknown',arch:'unknown'};}},
 label(info){return info.os==='win'?'Windows':info.os==='mac'?'Mac · '+(info.arch==='arm64'?'Apple Silicon':info.arch==='x86-64'?'Intel':info.arch):'Desteklenmeyen sistem';},
 help(info,id){return info.os==='win'?'$env:OLLAMA_ORIGINS="chrome-extension://'+id+'"\n$env:OLLAMA_HOST="127.0.0.1:11434"\n$env:OLLAMA_NO_CLOUD="1"\nollama serve':info.os==='mac'?'OLLAMA_ORIGINS="chrome-extension://'+id+'" OLLAMA_HOST="127.0.0.1:11434" OLLAMA_NO_CLOUD=1 /Applications/Ollama.app/Contents/Resources/ollama serve':'Bu sürüm Windows ve macOS içindir.';}
};
