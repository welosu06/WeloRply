const $=id=>document.getElementById(id);
const BASE='http://127.0.0.1:11434';
const selected=WELO_MODELS.find(m=>m.id===new URLSearchParams(location.search).get('model'));
let downloading=false,controller,hasModel=false,lastSaved=0;
const jobId=crypto.randomUUID();
function friendly(e){if(e.name==='AbortError')return 'İndirme iptal edildi.';if(e.name==='TimeoutError')return 'Ollama bağlantısı zaman aşımına uğradı.';if(e.message==='Failed to fetch')return 'Ollama’ya bağlanılamadı. Ollama kurulu ve açık olmalı.';return e.message;}
async function localFetch(url,options){
 let r;try{r=await fetch(url,options);}catch(e){if(e.name==='TimeoutError'||e.name==='AbortError')throw e;await startHelper();return fetch(url,url.endsWith('/api/tags')?{...options,signal:AbortSignal.timeout(10000)}:options);}
 if(r.status===403){await startHelper();return fetch(url,url.endsWith('/api/tags')?{...options,signal:AbortSignal.timeout(10000)}:options);}return r;
}
async function startHelper(){let r;try{r=await chrome.runtime.sendNativeMessage('com.welo.reply',{action:'ensure'});}catch{throw Error('Windows yardımcısını bir kez kur veya aşağıdaki bağlantı adımlarını uygula.');}if(!r?.ok)throw Error(r?.message||'Ollama başlatılamadı.');}
async function getModels(){const r=await localFetch(BASE+'/api/tags',{signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error(r.status===403?'Ollama erişimi reddetti (403). Aşağıdaki bağlantı adımlarını uygula.':'Ollama hatası: '+r.status);return (await r.json()).models||[];}
async function state(status,detail,percent=0,force=false){
 $('installStatus').textContent=detail;$('installProgress').value=percent;
 if(force||Date.now()-lastSaved>750){lastSaved=Date.now();await chrome.storage.local.set({modelInstall:{jobId,model:selected.id,status,detail,percent,updated:Date.now()}});}
}
async function check(){
 if(!selected||downloading)return;
 $('check').disabled=true;$('install').disabled=true;$('installStatus').textContent='Ollama kontrol ediliyor…';
 try{const names=await getModels();hasModel=names.some(m=>m.name===selected.id&&!m.remote_host);$('connectionHelp').hidden=true;$('installStatus').textContent=hasModel?'Bu model zaten kurulu. Kullanmak için aşağıya tıkla.':'Ollama hazır. Modeli indirebilirsin.';$('install').textContent=hasModel?'Bu modeli kullan':'İndir ve kullan';$('install').disabled=false;}
 catch(e){$('installStatus').textContent=friendly(e);$('connectionError').textContent=friendly(e);$('connectionHelp').hidden=false;}
 finally{$('check').disabled=false;}
}
async function activate(){const names=await getModels();if(!names.some(m=>m.name===selected.id&&!m.remote_host))throw Error('İndirme tamamlandı fakat model yerel listede doğrulanamadı. Bağlantıyı kontrol edip yeniden dene.');await chrome.storage.local.set({model:selected.id});await state('success','Model hazır ve Welo Reply’de seçildi: '+selected.name,100,true);hasModel=true;$('install').textContent='Bu modeli kullan';}
async function perform(){
 downloading=true;controller=new AbortController();$('install').disabled=true;$('cancel').disabled=false;$('check').disabled=true;$('connectionHelp').hidden=true;
 try{
 if(hasModel){await activate();return;}
 await state('downloading','Model indirmesi başlatılıyor…',0,true);
 const r=await localFetch(BASE+'/api/pull',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:selected.id,stream:true}),signal:controller.signal});
 if(!r.ok)throw Error(r.status===403?'Ollama erişimi reddetti (403). Bağlantı yardımını kontrol et.':'Model indirilemedi: HTTP '+r.status);
 const reader=r.body.getReader(),decoder=new TextDecoder();let buffer='',success=false;const layers=new Map();
 async function line(raw){
  if(!raw.trim())return;const p=JSON.parse(raw);if(p.error)throw Error(p.error);
  if(p.digest&&p.total)layers.set(p.digest,{total:p.total,completed:Math.min(p.total,p.completed||0)});
  let total=0,completed=0;for(const v of layers.values()){total+=v.total;completed+=v.completed;}
  const percent=total?Math.min(99,Math.floor(completed/total*100)):0;
  const detail=p.status==='success'?'İndirme tamamlandı, model doğrulanıyor…':p.status?.includes('verifying')?'Dosyalar doğrulanıyor…':p.status?.includes('pulling')?(total?'Model indiriliyor…':'İndirme hazırlanıyor…'):p.status?.includes('writing')?'Model kaydediliyor…':(p.status||'İndiriliyor…');
  $('installDetail').textContent=total?`${percent}% · ${(completed/1e9).toFixed(2)} / ${(total/1e9).toFixed(2)} GB`:'Hazırlanıyor';
  await state('downloading',detail,percent);
  if(p.status==='success')success=true;
 }
 while(true){const chunk=await reader.read();if(chunk.done)break;buffer+=decoder.decode(chunk.value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop();for(const raw of lines)await line(raw);}
 buffer+=decoder.decode();await line(buffer);
 if(!success)throw Error('İndirme tamamlanmadan bağlantı kesildi. Tekrar dene.');
 await activate();$('installDetail').textContent='Yan panele dönüp yorum üretmeye başlayabilirsin.';
 }catch(e){controller?.abort();await state(e.name==='AbortError'?'cancelled':'error',friendly(e),Number($('installProgress').value),true);if(e.message.includes('403')){$('connectionHelp').hidden=false;$('connectionError').textContent=friendly(e);}}
 finally{downloading=false;controller=null;$('install').disabled=false;$('cancel').disabled=true;$('check').disabled=false;}
}
$('install').onclick=async()=>{
 if(!selected||downloading)return;
 // Ayrı sekmelerde aynı anda iki indirmeyi engelle; uzun indirme arka plan işçisi zaman aşımına bağlı değildir.
 try{await navigator.locks.request('welo-model-install',{ifAvailable:true},async lock=>{if(!lock){$('installStatus').textContent='Başka bir model kurulum sekmesi çalışıyor. Önce o indirmeyi bitir veya iptal et.';return;}await perform();});}catch(e){$('installStatus').textContent=friendly(e);}
};
$('cancel').onclick=()=>controller?.abort();$('check').onclick=check;
$('originCommand').textContent='$env:OLLAMA_ORIGINS="chrome-extension://'+chrome.runtime.id+'"\nollama serve';
$('copyOrigin').onclick=()=>navigator.clipboard.writeText($('originCommand').textContent).then(()=>$('copyOrigin').textContent='Kopyalandı').catch(e=>$('connectionError').textContent=e.message);
window.addEventListener('beforeunload',e=>{if(downloading){e.preventDefault();e.returnValue='';}});
if(selected){$('modelName').textContent=selected.name;$('modelInfo').textContent=selected.size+' · '+selected.description;check();}else{$('installStatus').textContent='Geçersiz model. Welo Reply’nin Modeller sekmesinden bir model seç.';$('check').disabled=true;}


