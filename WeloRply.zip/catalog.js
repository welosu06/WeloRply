// Yalnızca yerel indirilebilir, sabit model listesi.
const WELO_MODELS=[
 {id:'qwen3.5:0.8b',name:'Qwen 3.5 · 0.8B',size:'Yaklaşık 1,2 GB',description:'Hız odaklı başlangıç seçeneği.'},
 {id:'qwen3.5:2b',name:'Qwen 3.5 · 2B',size:'Yaklaşık 2,7 GB',description:'Daha büyük model, daha fazla bellek kullanır.'},
 {id:'gemma3:1b',name:'Gemma 3 · 1B',size:'Yaklaşık 806 MB',description:'Hafif bir alternatif.'}
];
