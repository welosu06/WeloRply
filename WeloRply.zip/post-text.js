// Read only the selected post, or its expanded article on the matching detail page.
globalThis.WeloPostText={read(post){
 const clean=n=>(n?.innerText||n?.textContent||'').replace(/\u00a0/g,' ').trim();
 const owned=(root,selector)=>[...root.querySelectorAll(selector)].filter(n=>!n.closest('[role="dialog"]')&&(!n.closest('article[data-testid="tweet"]')||n.closest('article[data-testid="tweet"]')===post));
 const bodySelector='[data-testid="twitterArticleRichTextView"], [data-testid="tweetArticleRichTextView"], [data-testid="twitterArticleReadView"]';
 const titleSelector='[data-testid="twitter-article-title"], [data-testid="twitterArticleTitle"], [data-testid="tweetArticleTitle"]';
 let root=post;
 let bodies=owned(root,bodySelector);
 const target=[...post.querySelectorAll('a[href*="/status/"]')].find(a=>a.querySelector('time'))?.href.match(/\/status\/(\d+)/)?.[1];
 const current=location.pathname.match(/\/status\/(\d+)/)?.[1];
 const primary=post.closest('[data-testid="primaryColumn"]');
 // Expanded articles can render their body next to the author/action post.
 if(!bodies.length&&target&&target===current&&primary){root=primary;bodies=owned(root,bodySelector);}
 bodies=bodies.filter(n=>!bodies.some(other=>other!==n&&other.contains(n)));
 if(bodies.length){const parts=[...owned(root,titleSelector),...bodies].map(clean).filter(Boolean);const text=[...new Set(parts)].join('\n\n');if(text)return text.slice(0,12000);}
 return owned(post,'[data-testid="tweetText"]').map(clean).filter(Boolean).join('\n\n').slice(0,12000);
}};
