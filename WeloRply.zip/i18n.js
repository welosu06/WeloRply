// Localizes only registered Welo UI roots, never the surrounding X page.
(()=>{
 if(globalThis.WeloI18n)return;
 const dictionary=globalThis.WeloEnglish||{};
 const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const pattern=new RegExp(Object.keys(dictionary).sort((a,b)=>b.length-a.length).map(escape).join('|'),'g');
 let language='tr';const roots=new Map(),records=new WeakMap();
 function text(value){
  const raw=String(value??'');if(language!=='en')return raw;
  // Replies shown in operation logs are user content, not UI strings.
  if(raw.startsWith('Gönderim yapıldı:'))return 'Reply sent:'+raw.slice('Gönderim yapıldı:'.length);
  let match=raw.match(/^Yorum hazır · gönderime (\d+) sn\.$/);if(match)return `Reply ready · sending in ${match[1]} sec.`;
  match=raw.match(/^(\d+) link okundu\.$/);if(match)return `${match[1]} links read.`;
  match=raw.match(/^Yanıt çok uzun; (\d+) karakteri geçmeyen tek kısa cümle yaz\.$/);if(match)return `Reply too long; write one short sentence of at most ${match[1]} characters.`;
  match=raw.match(/^Yanıt dili gönderiyle uyuşmuyor\. Yalnızca (.+) dilinde yaz\.$/);if(match)return `The reply language does not match the post. Write only in ${match[1]}.`;
  return raw.replace(pattern,key=>dictionary[key]).replace(/(\d+) yerel model bulundu\./g,'$1 local models found.');
 }
 function ignored(node){const e=node.nodeType===1?node:node.parentElement;return !!e?.closest('script,style,textarea,pre,code,#model option,#modelName,#linkList a,[contenteditable],[data-welo-user-text]');}
 function renderValue(node,key,value,set){
  let entries=records.get(node);if(!entries){entries={};records.set(node,entries);}
  let entry=entries[key];if(!entry||entry.output!==value)entry=entries[key]={source:value,output:value};
  const output=text(entry.source);entry.output=output;if(value!==output)set(output);
 }
 function visit(node){
  if(ignored(node)){if(node.nodeType===1&&node.tagName==='TEXTAREA')for(const a of ['placeholder','aria-label','title'])if(node.hasAttribute(a))renderValue(node,a,node.getAttribute(a),v=>node.setAttribute(a,v));return;}
  if(node.nodeType===3){renderValue(node,'text',node.nodeValue,v=>node.nodeValue=v);return;}
  if(node.nodeType===1){for(const a of ['title','placeholder','aria-label'])if(node.hasAttribute(a))renderValue(node,a,node.getAttribute(a),v=>node.setAttribute(a,v));}
  for(const child of node.childNodes||[])visit(child);
 }
 function controls(root){for(const select of root.querySelectorAll?.('[data-welo-language]')||[]){select.value=language;if(select.dataset.weloBound)continue;select.dataset.weloBound='1';select.addEventListener('change',()=>setLanguage(select.value).catch(()=>{select.value=language;}));}}
 function apply(){if(location.protocol==='chrome-extension:'||document.documentElement.dataset.weloPage==='true')document.documentElement.lang=language;for(const [root,observer]of roots){visit(root);controls(root);}globalThis.dispatchEvent(new CustomEvent('welo-language-changed',{detail:language}));}
 function observe(root){if(roots.has(root))return;for(const [old,observer]of roots){if(!old.isConnected){observer.disconnect();roots.delete(old);}}const observer=new MutationObserver(mutations=>{for(const m of mutations){if(m.type==='childList'){for(const node of m.addedNodes)visit(node);}else{visit(m.target);}}controls(root);});roots.set(root,observer);visit(root);controls(root);observer.observe(root,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['title','placeholder','aria-label','data-welo-user-text']});}
 async function setLanguage(next){if(!['tr','en'].includes(next))return;await chrome.storage.local.set({uiLanguage:next});language=next;apply();}
 // Explicitly distinguish error/status output from generated reply content.
 function message(element,value){element.removeAttribute('data-welo-user-text');element.textContent=String(value??'');visit(element);}
 function userText(element,value){element.setAttribute('data-welo-user-text','');records.delete(element);element.textContent=String(value??'');}
 globalThis.WeloI18n={text,observe,setLanguage,message,userText,get language(){return language;}};
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.uiLanguage){language=changes.uiLanguage.newValue==='en'?'en':'tr';apply();}});
 const ready=chrome.storage.local.get('uiLanguage').then(s=>{language=s.uiLanguage==='en'?'en':'tr';apply();}).catch(()=>{});
 globalThis.WeloI18n.ready=ready;
 if(document.documentElement.dataset.weloPage==='true'){observe(document.documentElement);}
})();




