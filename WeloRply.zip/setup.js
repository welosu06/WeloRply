(()=>{
const embedded=!!document.getElementById('deviceSetup');
const $=id=>document.getElementById((embedded?'setup-':'')+id);let ready=false;
async function check(repair=false){$('check').disabled=$('repair').disabled=true;$('result').textContent='Kontrol ediliyor…';try{
 const helper=await chrome.runtime.sendMessage({type:repair?'helperRepair':'helperStatus'});
 if(repair&&!helper?.ok)throw Error(helper?.error||'Yardımcı bağlantısı kurulamadı.');
 const r=await chrome.runtime.sendMessage({type:'models'});if(!r?.ok)throw Error(r?.error||'Ollama bağlantısı kurulamadı.');ready=true;
 $('result').textContent=(helper.installed||repair?'Yardımcı bağlı. ':'Yardımcı yok; Ollama doğrudan bağlı. ')+(r.models.length?r.models.length+' yerel model bulundu.':'Henüz model yok; aşağıdan indir.');
 await chrome.storage.local.set({setupVerifiedAt:Date.now()});
 }catch(e){ready=false;$('result').textContent=e.message;}finally{$('check').disabled=$('repair').disabled=false;for(const b of $('models').querySelectorAll('button'))b.disabled=!ready;}}
$('check').onclick=()=>check();$('repair').onclick=()=>check(true);
async function initialize(){const info=await WeloPlatform.get();$('device').textContent=WeloPlatform.label(info);$('manual').textContent=WeloPlatform.help(info,chrome.runtime.id);const supported=['win','mac'].includes(info.os);
 if(!supported){$('guide').textContent='Bu paket yalnızca Windows ve macOS destekler.';$('check').disabled=$('repair').disabled=true;return;}
 $('ollama').hidden=$('package').hidden=false;$('ollama').href='https://ollama.com/download/'+(info.os==='win'?'windows':'mac');$('package').href='setup/welo-'+info.os+'.zip';$('package').download='welo-'+info.os+'-kurulum.zip';
 $('guide').textContent=info.os==='mac'?'Mac algılandı. macOS 14 veya yenisi gerekir. Ollama ve Node.js 22 veya yenisi kuruluysa doğrudan yardımcı paketine geç.':'Windows algılandı. Ollama kuruluysa doğrudan yardımcı paketine geç.';
 $('node').hidden=info.os!=='mac';$('steps').textContent=info.os==='mac'?'ZIP’i çıkart. Terminal’e bash ve bir boşluk yaz; Kur.command dosyasını Terminal’e sürükleyip Enter’a bas. Kurulum eksik bileşen varsa resmî sayfasını açar. Mac paketi henüz gerçek Mac üzerinde test edilmedi.':'ZIP’i çıkart. Setup.ps1 dosyasını PowerShell ile çalıştır. Eklenti kimliği hazır gelir; Kur ve başlat düğmesine bas. İmzasız betik engellenirse aşağıdaki yardımcısız yöntemi kullan.';
 for(const model of WELO_MODELS){const b=document.createElement('button');b.className='secondary full';b.textContent=model.name+' · '+model.size+' · İndir';b.disabled=true;b.onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('installer.html')+'?model='+encodeURIComponent(model.id)});$('models').append(b);}
 await chrome.storage.local.set({setupSeen:info.os});await check();}
let initialized=false;function open(){if(initialized)return;initialized=true;initialize().catch(e=>{initialized=false;$('result').textContent=e.message;});}
if(embedded)window.addEventListener('welo-open-setup',open);else open();
})();
