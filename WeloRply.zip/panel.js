const $=id=>document.getElementById(id);let running=false,stop=false,tabId,links=[],completed=new Set(),success=0,failed=0;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function log(t){const l=document.createElement('li');l.textContent=t;$('log').append(l);$('log').scrollTop=$('log').scrollHeight;}
function link(s){const u=new URL(s.trim());if(!['x.com','www.x.com','twitter.com','www.twitter.com'].includes(u.hostname)||u.protocol!=='https:'||!/^\/(?:[\w]+|i\/web)\/status\/\d+\/?$/.test(u.pathname))throw Error('Geçersiz link: '+s);return 'https://x.com'+u.pathname.replace(/\/$/,'');}
const postId=u=>u.match(/status\/(\d+)/)?.[1];
async function persistLinks(next){await chrome.storage.local.set({savedLinks:next});links=next;renderLinks();}
function renderLinks(){
 $('linkCount').textContent=links.length;$('linkList').replaceChildren();
 if(!links.length){const li=document.createElement('li');li.textContent='Henüz link eklenmedi.';$('linkList').append(li);return;}
 for(const url of links){const li=document.createElement('li');const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';a.textContent=(completed.has(postId(url))?'✓ ':'')+url;a.title=url;const b=document.createElement('button');b.className='remove';b.textContent='×';b.title='Listeden çıkar';b.disabled=running;b.onclick=()=>persistLinks(links.filter(x=>x!==url)).catch(e=>log(e.message));li.append(a,b);$('linkList').append(li);}
}
async function add(){
 const input=$('links').value.trim();if(!input)return;
 const found=input.match(/https:\/\/(?:www\.)?(?:x\.com|twitter\.com)\/[^\s<>"']+/g)||[];
 if(!found.length)throw Error('Geçerli bir X gönderi linki ekle.');
 const parsed=found.map(x=>link(x.replace(/[),.;]+$/,'')));
 const next=[...new Map([...links,...parsed].map(u=>[postId(u),u])).values()];
 await persistLinks(next);$('links').value='';log(parsed.length+' link okundu.');
}
async function saveWriting(){
 const writing={slowTyping:$('slowTyping').checked,typingCorrections:$('typingCorrections').checked,noEmoji:$('noEmoji').checked,noDash:$('noDash').checked,language:$('language').value,tone:$('tone').value,maxLength:Math.min(160,Math.max(80,Number($('maxLength').value)||140))};
 await chrome.storage.local.set(writing);
 }
 $('saveWriting').onclick=()=>saveWriting().then(()=>$('writingStatus').textContent='Yazım tercihlerin kaydedildi.').catch(e=>$('writingStatus').textContent=e.message);
 for(const key of ['slowTyping','typingCorrections'])$(key).onchange=async()=>{
  const field=$(key);field.disabled=true;
  try{const values={[key]:field.checked};if(key==='typingCorrections'&&field.checked)values.slowTyping=true;await chrome.storage.local.set(values);if(values.slowTyping===true)$('slowTyping').checked=true;$('writingStatus').textContent=key==='slowTyping'?(field.checked?'Yavaş yazım açık · otomatik kaydedildi.':'Yavaş yazım kapalı · otomatik kaydedildi.'):(field.checked?'Rastgele düzeltme ve yavaş yazım açık · kaydedildi.':'Rastgele düzeltme kapalı · kaydedildi.');}
  catch(e){field.checked=!field.checked;$('writingStatus').textContent='Ayar kaydedilemedi: '+e.message;}
  finally{field.disabled=false;}
 };
 function describeTone(){$('toneDescription').textContent=$('tone').selectedOptions[0]?.dataset.description||'';}
 $('tone').onchange=async()=>{describeTone();const field=$('tone');field.disabled=true;try{await chrome.storage.local.set({tone:field.value});$('writingStatus').textContent='Yorum tonu otomatik kaydedildi.';}catch(e){$('writingStatus').textContent='Ton kaydedilemedi: '+e.message;}finally{field.disabled=false;}};
 $('allowRepeatReplies').onchange=async()=>{const field=$('allowRepeatReplies');field.disabled=true;try{await chrome.storage.local.set({allowRepeatReplies:field.checked});$('repeatStatus').textContent=field.checked?'Tekrar yorum açık · kaydedildi.':'Tekrar yorum kapalı · kaydedildi.';}catch(e){field.checked=!field.checked;$('repeatStatus').textContent='Ayar kaydedilemedi: '+e.message;}finally{field.disabled=false;}};
 $('autoLike').onchange=async()=>{const field=$('autoLike');field.disabled=true;try{await chrome.storage.local.set({autoLike:field.checked});$('autoLikeStatus').textContent=field.checked?'Otomatik beğeni açık · kaydedildi.':'Otomatik beğeni kapalı · kaydedildi.';}catch(e){field.checked=!field.checked;$('autoLikeStatus').textContent='Ayar kaydedilemedi: '+e.message;}finally{field.disabled=false;}};
 async function save(){await saveWriting();if(!$('model').value)throw Error('Önce yerel bir model kur ve bağlantıyı yenile.');await chrome.storage.local.set({model:$('model').value,instruction:$('instruction').value,autoLike:$('autoLike').checked,delay:Math.max(30,Number($('delay').value)||45)});}
async function refreshModels(quiet=false){
 if(!quiet){$('badge').textContent='Bağlanıyor';$('badge').className='badge';$('models').disabled=true;}
 try{const r=await chrome.runtime.sendMessage({type:'models'});if(!r?.ok)throw Error(r?.error||'Ollama yanıt vermedi.');$('model').replaceChildren();for(const m of r.models){const o=document.createElement('option');o.value=m;o.textContent=m;$('model').append(o);}$('model').value=r.model;$('badge').textContent='Bağlı';$('badge').className='badge ok';$('status').textContent=r.model?'Hazır · '+r.model:'Ollama bağlı. Modeller sekmesinden bir model indir.';if(!r.model){const o=document.createElement('option');o.value='';o.textContent='Henüz model kurulu değil';$('model').append(o);}renderCatalog(r.models);}
 catch(e){$('badge').textContent='Bağlantı yok';$('badge').className='badge error';$('status').textContent=e.message;$('model').replaceChildren();const o=document.createElement('option');o.textContent='Ollama ve modeli kontrol et';o.value='';$('model').append(o);}
 finally{if(!running)$('models').disabled=false;}
}
$('models').onclick=refreshModels;
$('model').onchange=()=>chrome.storage.local.set({model:$('model').value}).then(()=>$('status').textContent='Model kaydedildi: '+$('model').value);
$('save').onclick=()=>save().then(()=>$('status').textContent='Ayarlar kaydedildi.').catch(e=>$('status').textContent=e.message);
$('add').onclick=()=>add().catch(e=>log(e.message));
$('copy').onclick=()=>navigator.clipboard.writeText(links.join('\n')).then(()=>log('Linkler kopyalandı.')).catch(e=>log(e.message));
$('clear').onclick=()=>persistLinks([]).catch(e=>log(e.message));
$('clearDone').onclick=async()=>{const data=await chrome.storage.local.get(null);await persistLinks(links.filter(u=>!completed.has(postId(u))&&data['sent_'+postId(u)]?.status!=='submitted'));};
$('stop').onclick=async()=>{stop=true;if(tabId)await chrome.tabs.sendMessage(tabId,{type:'cancel'}).catch(()=>{});log('Durdurma istendi. Tıklanmış gönderim geri alınamaz.');};
async function ready(id){const deadline=Date.now()+60000;while(Date.now()<deadline){if(stop)throw Error('Durduruldu.');const r=await WeloQueueTransport.timed(chrome.tabs.sendMessage(id,{type:'ping'}),2000,'Sekme yanıt vermiyor.').catch(()=>null);if(r?.ok&&r.version===chrome.runtime.getManifest().version)return;await sleep(500);}throw Error('X sekmesi yüklenemedi. Eklentiyi güncellediysen X sayfasını yenile.');}
function lock(value){for(const name of ['start','add','clear','clearDone','model','models','save','saveWriting','test'])$(name).disabled=value;$('stop').disabled=!value;renderLinks();}
$('start').onclick=async()=>{
 if(running)return;running=true;stop=false;lock(true);success=0;failed=0;completed.clear();$('success').textContent='0';$('failed').textContent='0';$('log').replaceChildren();
 try{
  await save();await add();const attempted=new Set();let urls=[...links];if(!urls.length)throw Error('En az bir link ekle.');
  $('progress').max=urls.length;$('progress').value=0;$('counter').textContent='0 / '+urls.length;
  for(let i=0;!stop;i++){
   const queue=await chrome.storage.local.get('savedLinks');urls=queue.savedLinks||links;
   const current=urls.find(url=>!attempted.has(postId(url)));if(!current)break;
   attempted.add(postId(current));const total=attempted.size+urls.filter(url=>!attempted.has(postId(url))).length;
   $('progress').max=Math.max($('progress').max,total);
   let result;tabId=null;
   $('progressText').textContent='Üretiliyor / gönderiliyor';log((i+1)+'/'+$('progress').max+' · '+current+' · İşleniyor…');
   try{
    $('progressText').textContent='X sayfası yükleniyor…';
    tabId=(await chrome.tabs.create({url:current,active:false})).id;
    await chrome.tabs.update(tabId,{autoDiscardable:false});
    await ready(tabId);if(stop)break;$('progressText').textContent='Gönderi metni bekleniyor…';
    result=await WeloQueueTransport.send(tabId,current,stage=>{if(running&&!stop)$('progressText').textContent=stage;},()=>stop);
    if(!result?.ok&&result?.retrySafe===true&&!stop){
     log('Gönderim başlamadan geçici hata oluştu. Aynı link bir kez yeniden deneniyor.');
     result=await WeloQueueTransport.send(tabId,current,stage=>{if(running&&!stop)$('progressText').textContent=stage;},()=>stop);
    }
    if(!result?.ok||result.draft===true)throw Error(result?.error||'Gönderim sonucu alınamadı. X üzerinde kontrol et.');
   }catch(e){
    if(stop)break;
    if(e.haltQueue)throw e;
    failed++;$('failed').textContent=failed;log('Link işlenemedi; listede bırakıldı: '+current+' · '+e.message);
    // Preserve the failed tab/draft for inspection; do not automatically retry it.
   }
   if(result?.ok&&result.draft!==true){
    success++;completed.add(postId(current));$('success').textContent=success;
    // Read current storage so links saved from X during this run are preserved.
    const latest=await chrome.storage.local.get('savedLinks');
    await persistLinks((latest.savedLinks||links).filter(url=>postId(url)!==postId(current)));
    log('Gönderim yapıldı: '+result.text);if(result.likeStatus)log(result.likeStatus);
    if(tabId)await chrome.tabs.remove(tabId).catch(()=>{});
   }
   tabId=null;$('progress').value=i+1;$('counter').textContent=(i+1)+' / '+$('progress').max;
   if(!stop)$('progressText').textContent='Sıradaki gönderi bekleniyor';
  }
  const remaining=await chrome.storage.local.get('savedLinks');
  const incomplete=(remaining.savedLinks||[]).length>0;
  $('progressText').textContent=stop?'Durduruldu':incomplete?'Tamamlanamadı · listede link kaldı':'Tamamlandı';
  log(stop?'Kuyruk durduruldu.':incomplete?'Bazı linkler tamamlanamadı. Hata kaydını kontrol et; belirsiz gönderimler otomatik tekrarlanmaz.':'Liste tamamlandı.');
 }catch(e){$('progressText').textContent=stop?'Durduruldu':'Durdu';log('Durdu: '+e.message);}
 finally{running=false;tabId=null;lock(false);}
};

function showView(name){for(const b of document.querySelectorAll('[data-tab]'))b.classList.toggle('active',b.dataset.tab===name);for(const view of ['home','modelStore','writing','settings','deviceSetup'])$(view).hidden=view!==name;}
for(const button of document.querySelectorAll('[data-tab]'))button.onclick=()=>showView(button.dataset.tab);
$('test').onclick=async()=>{const b=$('test');b.disabled=true;WeloI18n.message($('testResult'),'Yerel model üretiyor…');try{await save();const r=await chrome.runtime.sendMessage({type:'generate',text:$('testText').value});if(!r?.ok)throw Error(r?.error||'Yanıt alınamadı.');WeloI18n.userText($('testResult'),r.text);}catch(e){WeloI18n.message($('testResult'),e.message);}finally{b.disabled=false;}};
$('help').textContent='$env:OLLAMA_ORIGINS="chrome-extension://'+chrome.runtime.id+'"\nollama serve';
$('copyHelp').onclick=()=>navigator.clipboard.writeText($('help').textContent).then(()=>$('copyHelp').textContent='Kopyalandı').catch(e=>log(e.message));
chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;if(changes.savedLinks){links=changes.savedLinks.newValue||[];renderLinks();}if(changes.modelInstall){renderDownload(changes.modelInstall.newValue);if(changes.modelInstall.newValue?.status==='success'&&!running)refreshModels(true);}if(changes.model&&!running)refreshModels(true);});
(async()=>{const policy=await chrome.storage.local.get('replyPolicy');if(policy.replyPolicy!==1)await chrome.storage.local.set({replyPolicy:1,language:'auto',tone:'natural',maxLength:140,instruction:'Gönderinin dilinde, içeriğe özgü kısa ve olumlu tek bir cümle yaz. Genel övgü ve heyecan ifadeleri kullanma.'});const s=await chrome.storage.local.get(['instruction','savedLinks','delay','noEmoji','noDash','language','tone','maxLength','autoLike','slowTyping','typingCorrections','allowRepeatReplies']);$('slowTyping').checked=s.slowTyping===true;$('typingCorrections').checked=s.typingCorrections!==false;for(const key of ['noEmoji','noDash'])$(key).checked=s[key]!==false;$('autoLike').checked=s.autoLike===true;$('allowRepeatReplies').checked=s.allowRepeatReplies===true;for(const key of ['language','tone','maxLength'])if(s[key])$(key).value=s[key];if(!$('tone').value)$('tone').value='natural';describeTone();if(s.instruction)$('instruction').value=s.instruction;if(s.delay)$('delay').value=s.delay;links=s.savedLinks||[];renderLinks();await refreshModels();})();
window.addEventListener('beforeunload',e=>{if(running){e.preventDefault();e.returnValue='';}});

function openStore(){document.querySelector('[data-tab="modelStore"]').click();}
$('openStore').onclick=openStore;$('storeRefresh').onclick=()=>refreshModels();
let availableModels=[];
function renderCatalog(installed=availableModels){
 availableModels=installed;const box=$('modelCatalog');box.replaceChildren();
 for(const item of WELO_MODELS){
  const card=document.createElement('div');card.className='model-card';
  const title=document.createElement('h3');title.textContent=item.name;
  const size=document.createElement('span');size.className='model-size';size.textContent=item.size;
  const description=document.createElement('p');description.textContent=item.description;
  const button=document.createElement('button');button.className='primary full';const exists=installed.includes(item.id);button.textContent=exists?'Kurulu · Bu modeli kullan':'İndir ve kullan';
  button.onclick=async()=>{if(exists){await chrome.storage.local.set({model:item.id});await refreshModels(true);$('status').textContent='Seçildi: '+item.id;}else{await chrome.tabs.create({url:chrome.runtime.getURL('installer.html')+'?model='+encodeURIComponent(item.id),active:true});}};
  card.append(title,size,description,button);box.append(card);
 }
}
function renderDownload(job){
 $('downloadState').hidden=!job;if(!job)return;
 const stale=job.status==='downloading'&&Date.now()-job.updated>30000;
 $('downloadText').textContent=job.model+' · '+(stale?'Son durum: '+job.detail+'. İndirme sekmesini kontrol et.':job.detail);
 $('downloadProgress').value=job.percent||0;
}
renderCatalog();chrome.storage.local.get('modelInstall').then(s=>renderDownload(s.modelInstall));
// Ollama'dan başka bir yolla indirilen modelleri de açık panelde otomatik algıla.
setInterval(()=>{if(!running&&!document.hidden)refreshModels(true);},15000);

$('extensionId').textContent=chrome.runtime.id;
$('copyId').onclick=()=>navigator.clipboard.writeText(chrome.runtime.id).then(()=>$('helperState').textContent='Tanılama için eklenti kimliği kopyalandı. Tek dosyalı kurulumda kimliği girmen gerekmez.').catch(e=>$('helperState').textContent=e.message);
$('repairHelper').onclick=async()=>{const b=$('repairHelper');b.disabled=true;$('helperState').textContent='Ollama kontrol ediliyor ve gerekirse yeniden başlatılıyor…';try{const r=await chrome.runtime.sendMessage({type:'helperRepair'});if(!r?.ok)throw Error(r?.error||'Onarım tamamlanamadı.');$('helperState').textContent=r.message;await refreshModels(true);}catch(e){$('helperState').textContent=e.message;}finally{b.disabled=false;}};
chrome.runtime.sendMessage({type:'helperStatus'}).then(r=>{$('helperState').textContent=r.installed?(r.ready?'Cihaz yardımcısı kurulu · Ollama hazır.':'Cihaz yardımcısı kurulu · Bağlantıyı onar düğmesine basabilirsin.'):'Cihaz yardımcısı henüz kurulu değil. Bir kez kurulum yap.';}).catch(()=>$('helperState').textContent='Cihaz yardımcısı henüz kurulu değil.');

$('openSetup').onclick=()=>{showView('deviceSetup');window.dispatchEvent(new Event('welo-open-setup'));$('deviceSetup').scrollIntoView({block:'start'});};
$('closeSetup').onclick=()=>{showView('home');$('openSetup').focus();};
(async()=>{const info=await WeloPlatform.get();$('platformName').textContent=WeloPlatform.label(info);$('help').textContent=WeloPlatform.help(info,chrome.runtime.id);$('ollamaDownload').href='https://ollama.com/download/'+(info.os==='mac'?'mac':info.os==='win'?'windows':'');})().catch(e=>log('Kurulum ekranı açılamadı: '+e.message));

$('floatingEnabled').onchange=()=>chrome.storage.local.set({floatingEnabled:$('floatingEnabled').checked});
chrome.storage.local.get('floatingEnabled').then(s=>$('floatingEnabled').checked=s.floatingEnabled!==false);
chrome.storage.onChanged.addListener((c,a)=>{if(a!=='local')return;for(const k of ['tone','replyPurpose'])if(c[k]&&$(k)){$(k).value=c[k].newValue; if(k==='tone')describeTone();}for(const k of ['autoLike','slowTyping','typingCorrections','floatingEnabled'])if(c[k]&&$(k))$(k).checked=c[k].newValue===true;});
$('replyPurpose').onchange=()=>chrome.storage.local.set({replyPurpose:$('replyPurpose').value});
chrome.storage.local.get('replyPurpose').then(s=>$('replyPurpose').value=s.replyPurpose||'auto');

async function savePacing(reset=false){const min=Number($('pacingMin').value),max=Number($('pacingMax').value);if(!Number.isFinite(min)||!Number.isFinite(max)||min<1||max>3600||max<min)throw Error('1–3600 saniye seç; en çok, en azdan küçük olamaz.');await chrome.storage.local.set({pacingEnabled:$('pacingEnabled').checked,pacingMin:min,pacingMax:max,...(reset?{nextReplySlot:0}:{})});$('pacingStatus').textContent='Bekleme ayarı kaydedildi.';}
for(const key of ['pacingEnabled','pacingMin','pacingMax'])$(key).onchange=()=>savePacing(key==='pacingEnabled').catch(e=>$('pacingStatus').textContent=e.message);
chrome.storage.local.get(['pacingEnabled','pacingMin','pacingMax']).then(s=>{$('pacingEnabled').checked=s.pacingEnabled===true;$('pacingMin').value=s.pacingMin??10;$('pacingMax').value=s.pacingMax??20;});
chrome.storage.onChanged.addListener((c,a)=>{if(a!=='local')return;if(c.pacingEnabled)$('pacingEnabled').checked=c.pacingEnabled.newValue===true;for(const k of ['pacingMin','pacingMax'])if(c[k])$(k).value=c[k].newValue;});

function showTask(job){const names={queued:'Görev sayfası açılıyor',running:'Yorum görevi çalışıyor',stopping:'Durduruluyor',completed:'Yorum gönderildi',failed:'Görev tamamlanamadı',interrupted:'Görev kesildi',cancelled:'Görev iptal edildi'};$('taskStatus').textContent=job?(names[job.status]||job.status)+(job.error?' · '+job.error:''):'Etkin yorum görevi yok.';$('cancelTask').disabled=!job||!['queued','running'].includes(job.status);}
chrome.storage.local.get('activeReplyTask').then(s=>showTask(s.activeReplyTask));chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.activeReplyTask)showTask(c.activeReplyTask.newValue);});$('cancelTask').onclick=()=>chrome.runtime.sendMessage({type:'cancelReplyTask'}).then(r=>{if(!r?.ok)$('taskStatus').textContent=r?.error||'Durdurma isteği iletilemedi.';});

$('openTask').onclick=async()=>{try{const {activeReplyTask:job}=await chrome.storage.local.get('activeReplyTask');if(!job?.tabId)throw Error('Görev sekmesi yok.');await chrome.tabs.update(job.tabId,{active:true});}catch(e){$('taskStatus').textContent='Görev sekmesi açılamadı: '+e.message;}};


