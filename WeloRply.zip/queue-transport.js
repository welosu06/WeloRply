// Bounded messaging keeps an unresponsive tab from silently blocking the queue.
globalThis.WeloQueueTransport={
 timed(promise,ms,message){let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(message)),ms);})]).finally(()=>clearTimeout(timer));},
 async send(id,url,onProgress,isStopped){
  const prefs=await chrome.storage.local.get(['pacingEnabled','pacingMax']);
  const wait=prefs.pacingEnabled?Math.min(3600,Math.max(0,Number(prefs.pacingMax)||20))*1000:0;
  const limit=600000+wait;let finished=false,lastStage='';
  const report=async()=>{try{const ping=await this.timed(chrome.tabs.sendMessage(id,{type:'ping'}),3000,'Sekme yanıt vermiyor.');if(!finished&&ping?.stage&&ping.stage!==lastStage){lastStage=ping.stage;onProgress(lastStage);}}catch{if(!finished)onProgress('Görev sekmesinden yanıt bekleniyor…');}};
  const monitor=setInterval(()=>{if(!finished)report();},3000);
  let stopTimer;
  const stopSignal=new Promise((_,reject)=>{stopTimer=setInterval(()=>{if(isStopped())reject(Error('Durduruldu.'));},250);});
  try{return await this.timed(Promise.race([chrome.tabs.sendMessage(id,{type:'replyTo',url}),stopSignal]),limit,'Görev sekmesi süre içinde sonuç vermedi. Gönderimi X üzerinde kontrol et.');}
  catch(e){
   // Do not start another job while an unresponsive sender might still be active.
   e.haltQueue=true;
   await this.timed(chrome.tabs.sendMessage(id,{type:'cancel'}),3000,'Durdurma yanıtı alınamadı.').catch(()=>{});
   throw e;
  }finally{finished=true;clearInterval(monitor);clearInterval(stopTimer);}
 }
};

