// Plans a visible typing animation; the completed text is always identical to input.
(() => {
 const split=text=>[...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(text)].map(x=>x.segment);
 function plan(text,{corrections=true,random=Math.random}={}){
  const chars=split(text),words=[...text.matchAll(/\p{L}[\p{L}\p{M}]*/gu)];
  const candidates=words.slice(0,-1).filter(w=>split(w[0]).length>=3);
  let mistake=null;
  if(corrections&&candidates.length){
   const word=candidates[Math.floor(random()*candidates.length)];
   const wordChars=split(word[0]);
   const count=1+Math.floor(random()*Math.min(3,wordChars.length));
   const offset=Math.floor(random()*(wordChars.length-count+1));
   mistake={index:split(text.slice(0,word.index)).length+offset,count,wordStart:word.index,word:word[0],lastWordStart:words[words.length-1].index};
  }
  const actions=[];
  for(let i=0;i<chars.length;i++){
   if(mistake&&i===mistake.index){
    for(let j=0;j<mistake.count;j++){
     const alphabet='abcdefghijklmnopqrstuvwxyz';let n=Math.floor(random()*alphabet.length);
     if(alphabet[n]===chars[i+j])n=(n+1)%alphabet.length;
     actions.push({kind:'insert',text:alphabet[n],temporary:true});
    }
    actions.push({kind:'pause'});
    for(let j=0;j<mistake.count;j++)actions.push({kind:'delete'});
    actions.push({kind:'pause'});
   }
   actions.push({kind:'insert',text:chars[i],temporary:false});
  }
  return {actions,mistake};
 }
 globalThis.WeloTyping={plan,split};
})();
